#include <gtest/gtest.h>

TEST(DummyTest, AlwaysPasses) {
    EXPECT_TRUE(true);
}
