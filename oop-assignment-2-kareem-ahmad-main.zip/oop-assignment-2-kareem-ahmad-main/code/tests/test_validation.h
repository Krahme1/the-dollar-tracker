#ifndef TEST_VALIDATION_H
#define TEST_VALIDATION_H

class test_validation
{
public:
    test_validation();
};

#endif // TEST_VALIDATION_H
